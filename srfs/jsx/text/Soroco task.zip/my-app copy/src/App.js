import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import {
  Tab,
  Row,
  Col,
  Nav,
  NavItem,
  NavDropdown,
  MenuItem,
  Button
} from 'react-bootstrap';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabList: [
        {
          keyValue: 0,
          displayEmployeeValue: 'Add transaction',
          displayEmployeeLogin: ''
        }
      ],
      defaultActiveKeyTab: 0,
      employeeLogin: '',
      employeeName: ''
    };
  }

  renderTabListItem = () => {
    const tabList = this.state.tabList;
    let tabsCount = tabList.length;
    let tabListDetails = [];
    let maxTabLimit = 3;
    const menuList = [];
    let hasDropDown = false;
    for (let i = 0; i < tabsCount - 1; i++) {
      if (i < maxTabLimit) {
        if (tabList[i].keyValue !== 0) {
          tabListDetails.push(
            <NavItem key={`tab-id-${i}`} eventKey={tabList[i].keyValue}>
              <div className="tabContainer">
                <div className="tabElement">
                  <div>{tabList[i].displayEmployeeValue}</div>
                  <div>{tabList[i].displayEmployeeLogin}</div>
                </div>
                <div
                  className="glyphicon glyphicon-remove"
                  onClick={e =>
                    this.removeData(e, tabList[i].displayEmployeeValue)
                  }
                />
              </div>
            </NavItem>
          );
        }
      } else {
        if (tabList[i].keyValue !== 0) {
          hasDropDown = true;
          menuList.push(
            <MenuItem key={`tab-id-${i}`} eventKey={tabList[i].keyValue}>
              <div className="tabContainer">
                <div className="tabElement">
                  <div>{tabList[i].displayEmployeeValue}</div>
                  <div>{tabList[i].displayEmployeeLogin}</div>
                </div>
              </div>
            </MenuItem>
          );
        }
      }
    }
    if (hasDropDown) {
      const moreItems = tabsCount - maxTabLimit - 1;
      const dropDownTitle = `${moreItems} More`;
      tabListDetails.push(
        <NavDropdown
          eventKey=""
          title={dropDownTitle}
          id="nav-dropdown-within-tab"
        >
          {menuList}
        </NavDropdown>
      );
      hasDropDown = false;
    }
    tabListDetails.push(
      <NavItem key={0} eventKey={tabList[tabsCount - 1].keyValue}>
        <div className="tabContainer">
          <div className="glyphicon glyphicon-plus-sign tabElement" />
          <div>{tabList[tabsCount - 1].displayEmployeeValue}</div>
          <div />
        </div>
      </NavItem>
    );

    return tabListDetails;
  };

  renderTabPaneItem = () => {
    const tabPaneList = this.state.tabList;
    let tabPaneListDetails = [];

    for (
      let i = 0, tabPanesCount = tabPaneList.length;
      i < tabPanesCount;
      i++
    ) {
      if (tabPaneList[i].keyValue === 0) {
        tabPaneListDetails.push(
          <Tab.Pane key={`tab-pane-id-${i}`} eventKey={tabPaneList[i].keyValue}>
            {this.renderCreateData()}
          </Tab.Pane>
        );
      } else {
        tabPaneListDetails.push(
          <Tab.Pane key={`tab-pane-id-${i}`} eventKey={tabPaneList[i].keyValue}>
            <div className="tabContent">
              Hi {tabPaneList[i].displayEmployeeValue}
            </div>
          </Tab.Pane>
        );
      }
    }

    return tabPaneListDetails;
  };

  formValid = () => {
    return (
      this.state.employeeLogin &&
      this.state.employeeLogin.length &&
      this.state.employeeName &&
      this.state.employeeName.length
    );
  };

  handleChange = (event, fieldName) => {
    this.setState({ [fieldName]: event.target.value });
  };

  createData = e => {
    const tabListData = this.state.tabList;
    const tabListCount =
      tabListData && tabListData.length ? tabListData.length : 0;
    this.setState({
      tabList: []
    });
    tabListData.unshift({
      keyValue: tabListCount + 1,
      displayEmployeeValue: this.state.employeeName,
      displayEmployeeLogin: this.state.employeeLogin
    });
    this.setState({
      tabList: tabListData,
      defaultActiveKeyTab: tabListCount + 1,
      employeeName: '',
      employeeLogin: ''
    });
  };

  removeData = (e, displayEmployeeValue) => {
    const tabListData = this.state.tabList;
    this.setState({
      tabList: []
    });
    for (let i = 0, tabsCount = tabListData.length; i < tabsCount; i++) {
      if (tabListData[i].displayEmployeeValue == displayEmployeeValue) {
        tabListData.splice(i, 1);
        break;
      }
    }
    this.setState({
      tabList: tabListData,
      defaultActiveKeyTab: 0
    });
    e.preventDefault();
    e.stopPropagation();
  };

  handleSelect = key => {
    this.setState({ defaultActiveKeyTab: key });
  };

  renderCreateData() {
    return (
      <div className="container-fluid tabContent">
        <b>Create new tab:</b>
        <div className="row elementContainer">
          <div className="col-xs-3">Employee name</div>
          <div className="col-xs-4">
            <input
              type="text"
              value={this.state.employeeName}
              onChange={e => this.handleChange(e, 'employeeName')}
            />
          </div>
        </div>
        <div className="row elementContainer">
          <div className="col-xs-3">Employee login</div>
          <div className="col-xs-4">
            <input
              type="text"
              value={this.state.employeeLogin}
              onChange={e => this.handleChange(e, 'employeeLogin')}
            />
          </div>
        </div>
        <div className="row elementContainer btnSpacingTop">
          <div className="col-xs-offset-3 col-xs-4">
            <Button
              bsStyle="primary"
              onClick={this.createData}
              disabled={!this.formValid()}
            >
              Create
            </Button>
          </div>
        </div>
      </div>
    );
  }

  render() {
    return (
      <div>
        <div className="titleHeader boxAlignmentCustom">
          <b>SOROCO</b>
        </div>
        <div className="row">
          <div className="col-xs-6">
            <div className="boxAlignmentCustom">
              <b>Original Information</b>
            </div>
            <div className="mainContainer" />
          </div>
          <div className="col-xs-6">
            <div className="boxAlignmentCustom">
              <b>Validation data</b>
            </div>
            {this.renderTabSection()}
          </div>
        </div>
        <div className="btnContainer">
          <Button bsStyle="warning">Reject</Button>
          <Button bsStyle="success">Submit</Button>
        </div>
      </div>
    );
  }

  renderTabSection() {
    return (
      <div className="mainContainer">
        <Tab.Container
          id="tabs-with-dropdown"
          activeKey={this.state.defaultActiveKeyTab}
          onSelect={this.handleSelect}
        >
          <Row className="clearfix">
            <Col sm={12}>
              <Nav bsStyle="tabs">{this.renderTabListItem()}</Nav>
            </Col>
            <Col sm={12}>
              <div>
                <Tab.Content animation>{this.renderTabPaneItem()}</Tab.Content>
              </div>
            </Col>
          </Row>
        </Tab.Container>
      </div>
    );
  }
}

export default App;
