
const hosts = {
  coinmarketcap: 'https://api.coinmarketcap.com/'
}

export const API = {
  getCryptoList: (currencyType) => `${hosts.coinmarketcap}/v1/ticker/?limit=5&convert=${currencyType}`,
};

export default {
  API
};
