export const CRYPTO_LIST = [
  'SGD',
  'AUD',
  'EUR',
  'GBP',
  'USD',
  'VND'
];
