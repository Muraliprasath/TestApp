import dotProp from 'dot-prop';
/**
 * Sort Array
 * Sort Array - sorting nested attributes 'attribute.nested'

 * @param array
 * @param attributeName
 * @param ascending
 * @param numericOnly {Boolean}
 * @return {Array.<T>|*}
 */
export const sortArrayItems = (
  array,
  attributeName,
  ascending = true,
  numericOnly = false
) =>
  array.sort((item1, item2) => {
    if (attributeName) {
      let value1 = dotProp
          .get(item1, attributeName.replace(/\s/g, ''), '')
          .toLowerCase(),
        value2 = dotProp
          .get(item2, attributeName.replace(/\s/g, ''), '')
          .toLowerCase();
      let result;

      if (numericOnly) {
        const regexp = new RegExp(/(?![+-]?\d*\.?\d+|e[+-]\d+)[^0-9]/g);
        value1 = parseInt(value1.replace(regexp, '') || 0);
        value2 = parseInt(value2.replace(regexp, '') || 0);
      }

      if (value1 === value2) {
        result = 0;
      } else {
        result = value1 > value2 ? 1 : -1;
      }
      return ascending ? result : -1 * result;
    }
  });
