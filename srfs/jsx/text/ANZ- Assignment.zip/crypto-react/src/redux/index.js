/**
 * Combined reducer
 */

import { combineReducers } from 'redux';
import { crptoListReducer } from './CryptoCcyList/reducers';

export default combineReducers({
  crptoListReducer
});
