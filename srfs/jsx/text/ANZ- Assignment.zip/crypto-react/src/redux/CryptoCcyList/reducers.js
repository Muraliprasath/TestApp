import * as types from './types';
import { sortArrayItems } from '../../utils/utils';

const {
  API_CRYPTOLIST_CALL_REQUEST,
  API_CRYPTOLIST_CALL_SUCCESS,
  API_CRYPTOLIST_CALL_FAILURE,
  SORT_LIST_ITEMS
} = types;

const initialState = {
  fetching: false,
  crytpoList: null,
  error: null
};

export function crptoListReducer(state = initialState, action) {
  switch (action.type) {
    case API_CRYPTOLIST_CALL_REQUEST:
      return { ...state, fetching: action.payload, error: null };
    case API_CRYPTOLIST_CALL_SUCCESS:
      return { ...state, fetching: false, crytpoList: action.cryptoList };
    case API_CRYPTOLIST_CALL_FAILURE:
      return {
        ...state,
        fetching: false,
        crytpoList: null,
        error: action.error
      };
    case SORT_LIST_ITEMS: {
      const finalResult = sortArrayItems(
        [...state.crytpoList],
        action.payload.columnName,
        action.payload.ascendingOrder,
        action.payload.isNumeric
      );
      return { ...state, crytpoList: finalResult };
    }
    default:
      return state;
  }
}
