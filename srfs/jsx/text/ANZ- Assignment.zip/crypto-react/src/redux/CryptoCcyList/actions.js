import * as types from './types';
import API from '../../api/api';

const {
  API_CRYPTOLIST_CALL_REQUEST,
  API_CRYPTOLIST_CALL_SUCCESS,
  SORT_LIST_ITEMS
} = types;

export const getCryptoListAction = currencyType => async dispatch => {
  dispatch({ type: API_CRYPTOLIST_CALL_REQUEST, payload: true });
  const cryptoList = await API.getCryptoData(currencyType);
  dispatch({ type: API_CRYPTOLIST_CALL_SUCCESS, cryptoList });
  dispatch({ type: API_CRYPTOLIST_CALL_REQUEST, payload: false });
};

export const sortListItems = (columnName, ascendingOrder, isNumeric) => ({
  type: SORT_LIST_ITEMS,
  payload: { columnName, ascendingOrder, isNumeric }
});
