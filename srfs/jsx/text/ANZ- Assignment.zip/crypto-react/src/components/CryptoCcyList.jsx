import React from 'react';
import numeral from 'numeral';
import { CRYPTO_LIST } from '../utils/constants';
// import mockData from '../api/data';
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Input
} from 'reactstrap';
import { getCryptoData } from '../api/api';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import {
  getCryptoListAction,
  sortListItems
} from '../redux/CryptoCcyList/actions';
const css = require('./CryptoCcyList.css');

class CryptoCcyList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      cryptoDropdownOpen: false,
      selectedCurrencyValue: '',
      ascendingName: true,
      columnName: 'name',
      ascendingPercentage: true,
      columnPercentage: 'percent_change_24h',
      ascendingValue: true,
      columnValue: '',
      searchKey: ''
    };
    // This binding is necessary to make `this` work in the callback
    this.cryptoToggle = this.cryptoToggle.bind(this);
    this.onCurrencyChange = this.onCurrencyChange.bind(this);
    this.searchList = this.searchList.bind(this);
  }

  cryptoToggle() {
    this.setState(prevState => ({
      cryptoDropdownOpen: !prevState.cryptoDropdownOpen
    }));
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps) {
      const currencyType =
        `price_${this.state.selectedCurrencyValue.toLowerCase()}` || '';
      this.setState({
        columnValue: currencyType
      });
    }
  }

  onCurrencyChange(e) {
    this.setState(
      {
        selectedCurrencyValue: e.currentTarget.textContent,
        searchKey: ''
      },
      () => this.props.getCryptoListAction(this.state.selectedCurrencyValue)
    );
  }

  searchList(e) {
    this.setState({
      searchKey: e.target.value
    });
  }

  sortListItems(columnName, ascendingOrder) {
    if (this.props.cryptoCcyList && this.props.cryptoCcyList.length) {
      switch (columnName) {
        case 'name': {
          this.props.sortListItems(columnName, ascendingOrder, false);
          this.setState({ ascendingName: !this.state.ascendingName });
          break;
        }
        case 'percent_change_24h': {
          this.props.sortListItems(columnName, ascendingOrder, true);
          this.setState({
            ascendingPercentage: !this.state.ascendingPercentage
          });
          break;
        }
        case this.state.columnValue: {
          this.props.sortListItems(columnName, ascendingOrder, true);
          this.setState({
            ascendingValue: !this.state.ascendingValue
          });
          break;
        }
      }
    }
  }

  filterBySearch(array, key, value) {
    const arrayResult = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i][key].toLowerCase().includes(value.toLowerCase())) {
        arrayResult.push(array[i]);
      }
    }
    return arrayResult;
  }

  renderCryptoList() {
    const listItem = this.props.cryptoCcyList || [];
    const data = this.state.searchKey
      ? this.filterBySearch(listItem, 'name', this.state.searchKey)
      : listItem;
    const currencyType =
      `price_${this.state.selectedCurrencyValue.toLowerCase()}` || '';
    let cryptoListData = [];
    data.map(item =>
      cryptoListData.push(
        <div key={`crypto-item-${item.id}`} className={css.cryptoRow}>
          <div className={css.cryptoName}>{item.name}</div>
          <div className={css.cryptoPrice}>{`${
            this.state.selectedCurrencyValue
          } ${numeral(item[currencyType]).format('0,0.00')}`}</div>
          <div
            className={`${css.cryptoChange} ${
              item.percent_change_24h > 0
                ? css.positiveValue
                : css.negativeValue
            }`}
          >{`${item.percent_change_24h}%`}</div>
        </div>
      )
    );
    return cryptoListData;
  }

  renderCryptoDropdown() {
    const data = CRYPTO_LIST;
    const currencyLabel = this.state.selectedCurrencyValue
      ? this.state.selectedCurrencyValue
      : 'Currency';
    let cryptoList = [];
    data.map((item, index) => {
      cryptoList.push(
        <DropdownItem key={`currency-${index}`} onClick={this.onCurrencyChange}>
          {item}
        </DropdownItem>
      );
    });
    return (
      <Dropdown
        isOpen={this.state.cryptoDropdownOpen}
        toggle={this.cryptoToggle}
      >
        <DropdownToggle caret>{currencyLabel}</DropdownToggle>
        <DropdownMenu>{cryptoList}</DropdownMenu>
      </Dropdown>
    );
  }

  renderRowHeader() {
    return (
      <div className={css.cryptoRowHeader}>
        <div
          className={css.cryptoNameHeader}
          onClick={() =>
            this.sortListItems(this.state.columnName, this.state.ascendingName)
          }
        >
          Name
        </div>
        <div
          className={css.cryptoPriceHeader}
          onClick={() =>
            this.sortListItems(
              this.state.columnValue,
              this.state.ascendingValue
            )
          }
        >
          Value
        </div>
        <div
          className={css.cryptoChangeWoBorder}
          onClick={() =>
            this.sortListItems(
              this.state.columnPercentage,
              this.state.ascendingPercentage
            )
          }
        >
          Percentage
        </div>
      </div>
    );
  }

  renderSearchField() {
    return (
      <div className={css.searchContainer}>
        <Input
          className={css.searchItem}
          name="search"
          id="exampleEmail"
          placeholder="Search by Name"
          value={this.state.searchKey}
          onChange={this.searchList}
        />
      </div>
    );
  }

  render() {
    return (
      <div className={css.homeScreenWrap}>
        <div className={css.containerElement}>
          <div className={css.pageHeader}>
            <div className={css.titleContainer}>
              <span className={css.pageTitle}>Top 5 Cryptocurrency </span>
              {this.renderCryptoDropdown()}
            </div>
            {this.renderSearchField()}
          </div>

          {this.renderRowHeader()}
          {this.renderCryptoList()}
        </div>
      </div>
    );
  }
}

CryptoCcyList.propTypes = {
  getCryptoListAction: PropTypes.func
};

const mapStateToProps = state => ({
  cryptoCcyList: state.crptoListReducer.crytpoList
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(
    {
      getCryptoListAction,
      sortListItems
    },
    dispatch
  );

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CryptoCcyList);
