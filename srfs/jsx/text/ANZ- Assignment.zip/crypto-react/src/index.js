import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import CryptoCcyList from './components/CryptoCcyList';
import store from './storeConfig';
import '!style-loader!css-loader!bootstrap/dist/css/bootstrap.css';

function initialise() {
  const app = document.createElement('div');
  document.body.appendChild(app);
  ReactDOM.render(
    <Provider store={store}>
      <BrowserRouter>
        <CryptoCcyList />
      </BrowserRouter>
    </Provider>,
    app
  );
}

initialise();
