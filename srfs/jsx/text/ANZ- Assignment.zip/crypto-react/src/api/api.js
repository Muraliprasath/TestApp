import config from '../config/config';
import axios from 'axios';
const { API } = config;

export default {
  getCryptoData: async displayCcy => {
    const url = API.getCryptoList(displayCcy);
    const activityCode = await axios.get(url);
    if (activityCode.status === 200 && activityCode.data) {
      return activityCode.data;
    } else {
      throw new Error(activityCode);
    }
  }
};
