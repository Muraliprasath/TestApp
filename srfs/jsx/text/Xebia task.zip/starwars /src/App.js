import React, { Component, Fragment } from 'react';
import { Route, Switch } from 'react-router-dom';

import LoginContainer from './containers/Login/LoginContainer';
import PlanetsContainer from './containers/Planets/PlanetsContainer';
import './App.css';

class App extends Component {
  render() {
    return (
      <Fragment>
        <Switch>
          <Route exact path="/" component={LoginContainer} />
          <Route exact path="/planetsList" component={PlanetsContainer} />
        </Switch>
      </Fragment>
    );
  }
}

export default App;
