import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import IconButton from '@material-ui/core/IconButton';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import Grid from '@material-ui/core/Grid';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Lock from '@material-ui/icons/Lock';
import Button from '@material-ui/core/Button';
import find from 'lodash/find';
import './Login.css';

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      password: '',
      showPassword: false,
      username: '',
      fetching: false,
      isValidLogin: true
    };
  }

  componentWillMount = () => {
    this.props.getLoginAuthAction();
  };

  componentWillReceiveProps(nextprops) {
    if (nextprops) {
      this.setState({
        fetching: nextprops.fetching
      });
    }
  }

  renderLoginForm() {
    return (
      <div className="loginWrap">
        <div className="loginBox">
          <div>
            <img className="logo" src="/images/logo.png" />
          </div>
          <div>
            <Grid container spacing={8} alignItems="flex-end">
              <Grid item>
                <AccountCircle />
              </Grid>
              <Grid item>
                <FormControl>
                  <InputLabel htmlFor="adornment-username">Username</InputLabel>
                  <Input
                    id="adornment-username"
                    type={'text'}
                    value={this.state.username}
                    onChange={this.handleChange('username')}
                    autoComplete="off"
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton />
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>
            </Grid>
          </div>
          <div className="passwordContainer">
            <Grid container spacing={8} alignItems="flex-end">
              <Grid item>
                <Lock />
              </Grid>
              <Grid item>
                <FormControl>
                  <InputLabel htmlFor="adornment-password">Password</InputLabel>
                  <Input
                    id="adornment-password"
                    type={this.state.showPassword ? 'text' : 'password'}
                    value={this.state.password}
                    onChange={this.handleChange('password')}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="Toggle password visibility"
                          onClick={this.handleClickShowPassword}
                          onMouseDown={this.handleMouseDownPassword}
                          className="passwordShowIcon"
                        >
                          {this.state.showPassword ? (
                            <VisibilityOff />
                          ) : (
                            <Visibility />
                          )}
                        </IconButton>
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>
            </Grid>
          </div>
          <div>
            <Button
              variant="contained"
              size="small"
              className="btnLogin"
              onClick={this.onLoginClick}
              disabled={!this.formValid()}
            >
              <span className="loginLabel">Login</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
              >
                <path d="M21 3.01H3c-1.1 0-2 .9-2 2V9h2V4.99h18v14.03H3V15H1v4.01c0 1.1.9 1.98 2 1.98h18c1.1 0 2-.88 2-1.98v-14c0-1.11-.9-2-2-2zM11 16l4-4-4-4v3H1v2h10v3z" />
              </svg>
            </Button>
          </div>
          {this.state.isValidLogin ? (
            ''
          ) : (
            <div className="invalidUser">Invalid User...!</div>
          )}
        </div>
      </div>
    );
  }

  formValid() {
    return (
      this.state.username &&
      this.state.username.length &&
      this.state.password &&
      this.state.password.length
    );
  }

  handleChange = prop => event => {
    this.setState({ [prop]: event.target.value });
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };

  onLoginClick = () => {
    const loginList = this.props.loginList;
    if (loginList) {
      const isUserExits = find(loginList, item => {
        return (
          item.name === this.state.username &&
          item.birth_year === this.state.password
        );
      });
      if (isUserExits) {
        this.setState({ isValidLogin: true });
        this.props.history.push('/planetsList');
      } else {
        this.setState({ isValidLogin: false });
      }
    }
  };

  render() {
    return (
      <Fragment>
        {this.state.fetching ? (
          <div className="loginLoader" />
        ) : (
          <div>{this.renderLoginForm()}</div>
        )}
      </Fragment>
    );
  }
}

Login.propTypes = {
  getLoginAuthAction: PropTypes.func
};
