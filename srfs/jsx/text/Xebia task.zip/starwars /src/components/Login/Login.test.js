import React from 'react';
import PaymentAssist from './PaymentAssist';
import renderer from 'react-test-renderer';
import {BrowserRouter as Router} from 'react-router-dom'; 

describe('PaymentAssist component is rendered correctly', () => {
  it('renders correctly', () => {
    
    const rendered = renderer.create(
      <Router>
        <PaymentAssist />
      </Router>
      
    );
    expect(rendered.toJSON()).toMatchSnapshot();
  });
});