import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import IconButton from '@material-ui/core/IconButton';
import Grid from '@material-ui/core/Grid';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import { TablePaginationActionsWrapped } from './TablePaginationActions';
import { EnhancedTableHead, styles } from './EnhancedTableHead';
import './PlanetList.css';
import Search from '@material-ui/icons/Search';

class PlanetList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      order: 'asc',
      orderBy: 'name',
      data: [],
      page: 0,
      rowsPerPage: 10,
      count: 0,
      searchText: '',
      fetching: false
    };
  }

  componentDidMount() {
    if (this.state.data && !this.state.data.length) {
      const pageNo = 1;
      this.props.getPlanetsListAction(pageNo);
    }
  }

  componentWillReceiveProps(nextprops) {
    if (nextprops.planetsList && nextprops.planetsList.length) {
      this.setState({
        data: nextprops.planetsList,
        count: nextprops.count
      });
    }
    if (nextprops) {
      this.setState({
        fetching: nextprops.fetching
      });
    }
  }

  handleRequestSort = (event, property) => {
    const orderBy = property;
    let order = 'desc';

    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc';
    }

    this.setState({ order, orderBy });
  };

  handleChangePage = (event, page, direction) => {
    const { planetsList, pageURLNo } = this.props;
    if (direction === 'next') {
      const dataCount =
        planetsList && planetsList.length ? planetsList.length : 0;
      let rowsPerPage = this.rowsPerPage ? this.rowsPerPage : 10;
      let value = dataCount / rowsPerPage;
      let newPage = parseInt(value, 10);
      if (page >= newPage && pageURLNo !== -1) {
        this.props.getPlanetsListAction(pageURLNo);
      }
    }
    this.setState({ page });
  };

  handleChange = prop => event => {
    this.setState({ [prop]: event.target.value });
  };

  filterBySearch(array, key, value) {
    const arrayResult = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i][key].toLowerCase().includes(value.toLowerCase())) {
        arrayResult.push(array[i]);
      }
    }
    return arrayResult;
  }

  render() {
    const { classes } = this.props;
    const { order, orderBy, rowsPerPage, page, count, searchText } = this.state;
    let { data } = this.state;
    const emptyRows =
      rowsPerPage - Math.min(rowsPerPage, count - page * rowsPerPage);
    data = searchText ? this.filterBySearch(data, 'name', searchText) : data;
    return (
      <div className="planetsMainContainer">
        <div className="planetsSearchContainer">
          <div>{this.renderSearch()}</div>
          <div className="planetsTitle">Planets List</div>
          <div>
            <div className="logoutImage" onClick={this.handleLogout} />
          </div>
        </div>
        <div className="planetsTableContainer">
          {this.renderPlanetsTableContent(
            classes,
            order,
            orderBy,
            count,
            data,
            page,
            rowsPerPage,
            emptyRows
          )}
        </div>
        {this.state.fetching ? <div className="loadingSpinner" /> : ''}
      </div>
    );
  }

  handleLogout = () => {
    this.props.history.push('/');
  };

  renderPlanetsTableContent(
    classes,
    order,
    orderBy,
    count,
    data,
    page,
    rowsPerPage,
    emptyRows
  ) {
    return (
      <Paper className="planetsContainer">
        <div className="planetsContainer">
          <Table className="planetsContainer" aria-labelledby="tableTitle">
            <EnhancedTableHead
              order={order}
              orderBy={orderBy}
              onRequestSort={this.handleRequestSort}
              rowCount={count}
            />
            <TableBody className="planetsContainer">
              {data.length
                ? data
                    .sort(this.getSorting(order, orderBy))
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((item, index) => {
                      return (
                        <TableRow tabIndex={-1} key={index}>
                          <TableCell component="th" scope="row" padding="none">
                            {item.name}
                          </TableCell>
                          <TableCell numeric>{item.rotation_period}</TableCell>
                          <TableCell numeric>{item.orbital_period}</TableCell>
                          <TableCell numeric>{item.diameter}</TableCell>
                          <TableCell>{item.climate}</TableCell>
                          <TableCell>{item.gravity}</TableCell>
                          <TableCell>{item.terrain}</TableCell>
                          <TableCell numeric>{item.surface_water}</TableCell>
                          <TableCell numeric>{item.population}</TableCell>
                        </TableRow>
                      );
                    })
                : ''}
              {emptyRows > 0 && (
                <TableRow style={{ height: 49 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        <TablePagination
          component="div"
          count={count}
          rowsPerPage={rowsPerPage}
          page={page}
          onChangePage={this.handleChangePage}
          rowsPerPageOptions={[]}
          colSpan={3}
          ActionsComponent={TablePaginationActionsWrapped}
        />
      </Paper>
    );
  }

  getSorting(order, orderBy) {
    return order === 'desc'
      ? (a, b) => (b[orderBy] < a[orderBy] ? -1 : 1)
      : (a, b) => (a[orderBy] < b[orderBy] ? -1 : 1);
  }

  renderSearch() {
    return (
      <Grid container spacing={8} alignItems="flex-end">
        <Grid item>
          <Search />
        </Grid>
        <Grid item>
          <FormControl>
            <InputLabel htmlFor="adornment-username">Search by name</InputLabel>
            <Input
              id="adornment-username"
              type={'text'}
              value={this.state.searchText}
              autoComplete="off"
              onChange={this.handleChange('searchText')}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton />
                </InputAdornment>
              }
            />
          </FormControl>
        </Grid>
      </Grid>
    );
  }
}

PlanetList.propTypes = {
  classes: PropTypes.object.isRequired,
  getPlanetsListAction: PropTypes.func
};

export default withStyles(styles)(PlanetList);
