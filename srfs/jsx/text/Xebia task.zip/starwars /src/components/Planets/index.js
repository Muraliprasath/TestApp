import PlanetList from './PlanetList';
export default PlanetList;