import PlanetsContainer from './PlanetsContainer';
export default PlanetsContainer;
