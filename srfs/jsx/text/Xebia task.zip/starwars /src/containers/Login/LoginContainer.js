import { withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { getLoginAuthAction } from '../../redux/Login/actions';
import Login from '../../components/Login';

const mapStateToProps = state => ({
  fetching: state.loginReducer.fetching,
  error: state.loginReducer.error,
  loginList: state.loginReducer.loginList
});

const mapDispatchToProps = dispatch => {
  return bindActionCreators(
    {
      getLoginAuthAction
    },
    dispatch
  );
};

const LoginContainer = withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Login)
);

export default LoginContainer;
