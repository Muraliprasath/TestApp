/**
 * Combined reducer
 */

import { combineReducers } from 'redux';
import { loginReducer } from './Login/reducers';
import { planetsListReducer } from './PlanetsList/reducers';

export default combineReducers({
  loginReducer,
  planetsListReducer
});
