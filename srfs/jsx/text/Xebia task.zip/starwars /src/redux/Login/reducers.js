import * as types from './types'
const { API_LOGIN_CALL_REQUEST, API_LOGIN_CALL_SUCCESS, API_LOGIN_CALL_FAILURE } = types;

const initialState = {
  fetching: false,
  loginList: null,
  error: null
};

export function loginReducer(state = initialState, action) {
  switch (action.type) {
    case API_LOGIN_CALL_REQUEST:
      return { ...state, fetching: action.payload, error: null };
    case API_LOGIN_CALL_SUCCESS:
      return { ...state, fetching: false, loginList: action.usersList };
    case API_LOGIN_CALL_FAILURE:
      return { ...state, fetching: false, loginList: null, error: action.error };
    default:
      return state;
  }
}
