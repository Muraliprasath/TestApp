import axios from 'axios';

export default {
  getLoginAuth: async pageNo => {
    try {
      return axios({
        method: 'get',
        url: `https://swapi.co/api/people?page=${pageNo}`
      });
    } catch (e) {
      return null;
    }
  },

  getPlanetsList: async pageNo => {
    try {
      return axios({
        method: 'get',
        url: `https://swapi.co/api/planets?page=${pageNo}`
      });
    } catch (e) {
      return null;
    }
  }
};
